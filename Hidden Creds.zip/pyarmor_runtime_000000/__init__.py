# Pyarmor 8.2.5 (trial), 000000, 2023-06-11T21:39:47.711601
from .pyarmor_runtime import __pyarmor__
