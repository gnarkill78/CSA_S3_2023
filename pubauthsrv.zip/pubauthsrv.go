package main
import (
	"golang.org/x/crypto/nacl/sign"
	"crypto/rand"
	"log"
	"encoding/base64"
	"encoding/json"
	"io/ioutil"
	"net/http"
    "github.com/gin-gonic/gin"
    "os"
    // "strings"

)

type authtoken struct {
	Cookie  string  `json:"cookie"`
}


type user struct {
    Username  string  `json:"username"`
    Password string  `json:"password"`
}

var users []user

var pubkey *[64]byte
var privkey *[32]byte

// adds an user from JSON received in the request body.
func rego(c *gin.Context) {
    var newUser user

    // Call BindJSON to bind the received JSON to
    // newUser.
    if err := c.BindJSON(&newUser); err != nil {
        return
    }
    if newUser.Username == "admin" {
    	c.IndentedJSON(http.StatusForbidden, "cannot register as this user")
    	return
    }
    // Add the new album to the slice.
    users = append(users, newUser)
    c.IndentedJSON(http.StatusCreated, newUser.Username)
}

func login(c *gin.Context) {
    var tryUser user
    if err := c.BindJSON(&tryUser); err != nil {
        return
    }

    for _, user := range users {
    	if user == tryUser {
    		// token = authtoken{Username: user.Username}
    		// out := make([]byte, 300)
    		out := make([]byte,0)
    		log.Println("username", []byte(user.Username), "pubkey",pubkey)
    		signedtokenout := sign.Sign(out, []byte(user.Username), pubkey)
    		log.Println("signed token:",signedtokenout)
    		signedtokenstr := base64.RawURLEncoding.EncodeToString(signedtokenout[:])
    		c.IndentedJSON(http.StatusOK, gin.H{"cookie":signedtokenstr})
    		return
    	}
    }
    c.IndentedJSON(http.StatusForbidden, "wrong")

}

func secret(c *gin.Context) {
	cookie, _ := c.Cookie("authtoken")
	outbuf := make([]byte, base64.RawURLEncoding.DecodedLen(len(cookie)))
	// outlen, _ := 
	base64.RawURLEncoding.Decode(outbuf, []byte(cookie))
	log.Printf("decoded: %v\n", outbuf)
	out := make([]byte,0)
	bytesOut, valid := sign.Open(out, outbuf, privkey)
	log.Printf("Opened bytes output: %v\nout: %s\n", bytesOut, out)

	if valid && string(bytesOut) == "admin" {
		c.IndentedJSON(http.StatusOK, os.Getenv("FLAG"))
	} else if valid {
		c.IndentedJSON(http.StatusForbidden, "not admin")
	} else {
		c.IndentedJSON(http.StatusForbidden, "invalid cookie")
	}
	

}

func home(c *gin.Context) {
	c.IndentedJSON(http.StatusOK, gin.H{"pubkey":base64.RawURLEncoding.EncodeToString(pubkey[:])})
}

func main() {

	bytes, err := ioutil.ReadFile("users.json")
	if err != nil {
        log.Println("Unable to load users file!")
        return
    }
    err = json.Unmarshal(bytes, &users)
    if err != nil {
        log.Println("Unable to unmarshal users file!")
        return
    }


	privkey,pubkey, _ = sign.GenerateKey(rand.Reader)
	// if err != nil {
	// 	log.Fatal("could not GenerateKey", err)
	// }
	log.Printf("pub:%v\npriv:%v\n", pubkey,privkey)

	pubstr := base64.RawURLEncoding.EncodeToString(pubkey[:])
    log.Println("pub key:", pubstr)

    router := gin.Default()

    router.POST("/rego", rego)
    router.POST("/login", login)
    router.GET("/secret", secret)
    router.GET("/", home)

    router.Run("0.0.0.0:80")

}